from pathlib import Path
import zipfile,json
root=Path(__file__).resolve().parent.parent
p=root/'test-results/clinical-accessibility-act-83f09-le-preserves-source-actions/trace.zip'
rows=[]
with zipfile.ZipFile(p) as z:
 for name in z.namelist():
  if not name.endswith('.trace'):continue
  for line in z.read(name).decode('utf8').splitlines():
   if any(t in line.lower() for t in ['[vite]','navigated','reload']):
    row=json.loads(line);rows.append(row)
out=root/'evidence/clinical-motion-20261004/first-run-reload-evidence.json'
out.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf8')
for r in rows:print(json.dumps(r,ensure_ascii=True)[:1000])
