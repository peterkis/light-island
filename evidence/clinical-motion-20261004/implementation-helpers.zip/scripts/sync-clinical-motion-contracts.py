from pathlib import Path
root=Path(__file__).resolve().parent.parent
update='''
## 2026-10-04 · U 型与原生连续形变恢复

此节按用户最新选择替代临床模块的圆弧外耳形状与瞬时几何降级。默认视觉总宽高恢复为 160×34 DIP；7 DIP 耳角收在总宽内部，下方双三次曲线与旧版 U 形一致。保留 400 DIP 基线的临床可滚动详情、200% / 225% 文字适配，未将新业务内容退回旧单行通知。

展开使用旧版 ζ=.84、ω=13 归一化轻弹簧（宽度540ms，高度单调），收回340ms；内容短暂退出、按最终布局进入，不缩放文字、不加全屏模糊。隐私/权限收紧立即删除敏感 DOM，不为淡出保留患者快照。默认悬停仍不自动展开或改变外壳。

原生 HWND 画布在普通转换中保持固定。仅在有限动画期允许单在途、最新帧合并的 HRGN 交接，原生准备前/后相邻轮廓并集后才绘制，最终收敛为真实轮廓；不是将整个画布设为可点击。旧 epoch、帧序号、关闭阶段及卸载均受保护。此为对原“所有逐帧区域 IPC 禁止”的最小例外，绝不允许逐帧 resize HWND 或空闲轮询。

数值与路径唯一权威：`docs/Dynamic-Island-UI-Spec.md` 1.1 的第3/4/9/10章；执行 `npm run tokens:clinical` 生成。当前验证记录目录 `evidence/clinical-motion-20261004/`，不得引用旧的静态路径结果作为本轮动效通过证据。Figma 再次读取被 Starter 额度拒绝，本轮未修改远端画板。
'''
for name in ['README.md','docs/CLINICAL-IMPLEMENTATION.md','docs/prd/Clinical-Island-Scenarios.md','docs/prd/Clinical-Island-Free-Plan-Continuation-20261002.md']:
 p=root/name;s=p.read_text(encoding='utf8');p.write_text(s+'\n'+update,encoding='utf8')
p=root/'AGENTS.md';s=p.read_text(encoding='utf8');s+='''
## Clinical U-notch / continuous motion (2026-10-04, supersedes the clinical static fallback)
- The accepted default contour is the legacy inward-ear cubic U, 160x34 DIP at normal text scale. Do not restore the 180-wide external circular ears.
- Rich clinical content remains measured, scrollable and read-only. Hover never auto-expands clinical details.
- Use UI spec 1.1/generated tokens. Restore the finite 540ms width spring / monotone height and 340ms collapse; never scale text or replay exit on mouseleave.
- Ordinary transitions keep HWND fixed. Finite single-in-flight HRGN previous/next silhouette handoff is explicitly permitted; per-frame HWND resize, idle region updates and full-canvas hit targets remain forbidden.
- Protect epoch, sequence, completion and cleanup at both sides. Authorization changes remove sensitive DOM immediately, including during outgoing presentation.
- Fresh evidence belongs to evidence/clinical-motion-20261004. Native geometry cadence and actual screen continuity are separate tests.
''';p.write_text(s,encoding='utf8')
print('Implementation, PRD continuation and agent constraints updated without changing source workflow scope')
