from pathlib import Path
import shutil
root=Path(__file__).resolve().parent.parent
out=root/'evidence/clinical-motion-20261004'
for name in ['native-click-focus.json','native-witness.log']:
 shutil.copy2(out/name,out/('before-svg-owner-'+name))
p=root/'src/clinical/ClinicalIsland.tsx';s=p.read_text(encoding='utf8')
old='aria-hidden="true" width={width} height={height} style={{left:0}}'
new='aria-hidden="true" width={T.geometry.idle.width} height={T.geometry.idle.height} style={{left:0}}'
assert old in s;s=s.replace(old,new)
s=s.replace('   <svg ref={svg}', '   {/* Animated SVG dimensions/path belong only to useClinicalLayout; React must not reset its viewport on view swaps. */}\n   <svg ref={svg}')
p.write_text(s,encoding='utf8')
p=root/'scripts/qa-clinical-motion.mjs';s=p.read_text(encoding='utf8').replace("transform:getComputedStyle(content).transform", "transform:getComputedStyle(content).transform,svgWidth:Number(e.querySelector('svg.ci-shell').getAttribute('width')),svgHeight:Number(e.querySelector('svg.ci-shell').getAttribute('height'))")
s=s.replace("assert(rows.every(r=>r.y===0));", "assert(rows.every(r=>r.y===0));assert(rows.every(r=>Math.abs(r.svgWidth-r.w)<.03&&Math.abs(r.svgHeight-r.h)<.03),'React must not resize the SVG viewport before the accepted shell frame');")
p.write_text(s,encoding='utf8')
for name in ['docs/CLINICAL-MOTION-RESTORE.md','AGENTS.md']:
 p=root/name;s=p.read_text(encoding='utf8');s+='\nSVG width/height/viewBox/path must have one animation owner. React declares only the initial size and must not replace the SVG viewport with target dimensions while the previously painted path is still present. Native screen capture caught transient collapse artifacts from that mismatch; the finite native regression samples viewport/surface equality as well as FPS.\n';p.write_text(s,encoding='utf8')
print('Removed competing React SVG viewport updates; preserved pre-fix native frames')
