#[tauri::command]
pub fn clinical_layout(window:WebviewWindow,epoch:u64,body_width:f64,height:f64,radius:f64,ear:f64,visible:bool,sequence:Option<u64>,phase:Option<String>,previous:Option<Shape>)->Result<bool,String>{
 ensure(&window)?;
 let target=Shape{width:body_width,height,radius,ear};validate(&target)?;
 if let Some(g)=&previous{validate(g)?;}
 let stage=phase.as_deref().unwrap_or("commit");
 if !["frame","commit","cancel"].contains(&stage){return Err("Invalid motion phase".into());}
 let mut guard=EPOCH.lock().map_err(|_|"Layout epoch unavailable")?;
 if stage=="cancel"{guard.cancel(epoch);record(&window,"clinical-cancel",json!({"epoch":epoch}));return Ok(true);}
 if epoch<guard.epoch||(epoch==guard.epoch&&guard.closed){record(&window,"clinical-stale",json!({"epoch":epoch}));return Ok(false);}
 if epoch>guard.epoch{guard.begin(epoch);}
 if !guard.frame(epoch,sequence.unwrap_or(1)){return Ok(false);}
 if stage=="commit"{guard.commit(epoch);}
 let p=plan(&window)?;canvas(&window,&p)?;
 #[cfg(target_os="windows")]unsafe{
  let hwnd=window.hwnd().map_err(|e|e.to_string())?;
  if !visible{ffi::ShowWindow(hwnd.0 as _,0);record(&window,"clinical-hidden",json!({"epoch":epoch}));return Ok(true);}
  let mut client=ffi::Rect::default();if ffi::GetClientRect(hwnd.0 as _,&mut client)==0{return Err("Clinical client rectangle unavailable".into());}
  let scale=ffi::GetDpiForWindow(hwnd.0 as _) as f64/96.0;if scale<=0.0{return Err("Clinical DPI unavailable".into());}
  let region=ffi::CreateRectRgn(0,0,0,0);if region.is_null(){return Err("Cannot allocate clinical region".into());}
  let combined=(||{
   add_outline(region,&target,(client.right-client.left) as u32,scale)?;
   // Only the previously painted and next frame: never use the whole canvas as a hit region.
   if stage=="frame"{if let Some(old)=&previous{add_outline(region,old,(client.right-client.left) as u32,scale)?;}}
   Ok::<(),String>(())
  })();
  if let Err(e)=combined{ffi::DeleteObject(region);return Err(e);}
  let old=ffi::CreateRectRgn(0,0,0,0);let equal=!old.is_null()&&ffi::GetWindowRgn(hwnd.0 as _,old)>0&&ffi::EqualRgn(old,region)!=0;
  if !old.is_null(){ffi::DeleteObject(old);}
  if equal{ffi::DeleteObject(region);}else if ffi::SetWindowRgn(hwnd.0 as _,region,0)==0{ffi::DeleteObject(region);return Err("Cannot install clinical outline".into());}
  if ffi::IsWindowVisible(hwnd.0 as _)==0{ffi::ShowWindow(hwnd.0 as _,4);}
  record(&window,"clinical-layout",json!({"epoch":epoch,"sequence":sequence,"phase":stage,"bodyWidth":body_width,"height":height,"equalRegion":equal}));
 }
 Ok(true)
}
