from pathlib import Path
p=Path(__file__).resolve().parent.parent/'src-tauri/src/clinical_window.rs'
s=p.read_text(encoding='utf8')
s=s.replace('//! Static native geometry + content-only fading, the UI spec\'s safe fallback.\n//! No frame-based region updates, mouse polling, arbitrary external URLs or clinical writes.','//! Stable canvas; finite, ordered silhouette handoff for the restored U-notch motion.\n//! No per-frame HWND resizing, idle polling, arbitrary external URLs or clinical writes.')
s=s.replace('use serde_json::{json, Value};','use serde_json::{json, Value};\nuse serde::Deserialize;\nuse crate::notch_geometry::EpochGuard;')
s=s.replace('static EPOCH:Mutex<u64>=Mutex::new(0);','static EPOCH:Mutex<EpochGuard>=Mutex::new(EpochGuard{epoch:0,sequence:0,closed:false});\n#[derive(Clone,Deserialize)]\npub struct Shape{width:f64,height:f64,radius:f64,ear:f64}')
s=s.replace('pub fn GetWindowRect(h:*mut c_void,r:*mut Rect)->i32;','pub fn GetWindowRect(h:*mut c_void,r:*mut Rect)->i32;\n  pub fn GetClientRect(h:*mut c_void,r:*mut Rect)->i32;\n  pub fn GetDpiForWindow(h:*mut c_void)->u32;')
s=s.replace('number("/geometry/expanded/preferredMaxWidth")+2.0*number("/geometry/earRadius")','number("/geometry/expanded/preferredMaxWidth")+(number("/geometry/expanded/preferredMaxWidth")-96.0)*number("/motion/expand/spring/maxWidthOvershootRatio")')
a=s.index('fn contour(');b=s.index('#[tauri::command]\npub async fn open_clinical_source',a)
replacement=r'''
fn contour(w:f64,h:f64,radius:f64,ear:f64)->Vec<[f64;2]>{
 let e=ear.min(w/8.0).min(h/4.0);let r=radius.min((w-2.0*e)/2.0).min(h-e);
 let mut p=vec![[0.0,0.0],[w,0.0]];
 fn curve(p:&mut Vec<[f64;2]>,a:[f64;2],b:[f64;2],end:[f64;2]){
  let start=*p.last().unwrap();for i in 1..=12{let t=i as f64/12.0;let s=1.0-t;
   p.push([s.powi(3)*start[0]+3.0*s*s*t*a[0]+3.0*s*t*t*b[0]+t.powi(3)*end[0],s.powi(3)*start[1]+3.0*s*s*t*a[1]+3.0*s*t*t*b[1]+t.powi(3)*end[1]]);}
 }
 curve(&mut p,[w-0.55*e,0.0],[w-e,0.45*e],[w-e,e]);p.push([w-e,h-r]);
 curve(&mut p,[w-e,h-0.55*r],[w-e,h-0.35*r],[w-e-0.175*r,h-0.175*r]);
 curve(&mut p,[w-e-0.35*r,h],[w-e-0.55*r,h],[w-e-r,h]);p.push([e+r,h]);
 curve(&mut p,[e+0.55*r,h],[e+0.35*r,h],[e+0.175*r,h-0.175*r]);
 curve(&mut p,[e,h-0.35*r],[e,h-0.55*r],[e,h-r]);p.push([e,e]);
 curve(&mut p,[e,0.45*e],[0.55*e,0.0],[0.0,0.0]);p
}
fn validate(g:&Shape)->Result<(),String>{
 let max=number("/geometry/expanded/preferredMaxWidth");let extra=(max-96.0)*number("/motion/expand/spring/maxWidthOvershootRatio");
 if [g.width,g.height,g.radius,g.ear].iter().any(|v|!v.is_finite())||!(95.0..=max+extra).contains(&g.width)||!(26.0..=number("/geometry/expanded/preferredMaxHeight")+0.001).contains(&g.height)||!(0.0..=33.0).contains(&g.radius)||!(0.0..=number("/geometry/earRadius")).contains(&g.ear){return Err("Clinical geometry exceeds UI limits".into());}Ok(())
}
#[cfg(target_os="windows")]
unsafe fn add_outline(region:*mut std::ffi::c_void,g:&Shape,canvas:u32,scale:f64)->Result<(),String>{
 let offset=(canvas as f64-g.width*scale)/2.0;let points=contour(g.width,g.height,g.radius,g.ear);
 let fringe=number("/geometry/pixelBoundaryTolerance") as i32;
 for dy in -fringe..=fringe{for dx in -fringe..=fringe{
  let native:Vec<ffi::Point>=points.iter().map(|pt|ffi::Point{x:(offset+pt[0]*scale).round() as i32+dx,y:(pt[1]*scale).round() as i32+dy}).collect();
  let part=ffi::CreatePolygonRgn(native.as_ptr(),native.len() as i32,2);
  if part.is_null(){return Err("Cannot allocate outline".into());}
  let ok=ffi::CombineRgn(region,region,part,2);ffi::DeleteObject(part);if ok==0{return Err("Cannot combine outline".into());}
 }}
 Ok(())
}
'''
s=s[:a]+replacement+s[b:]
p.write_text(s,encoding='utf8')
print('Cubic outline and bounded native guard prepared')
