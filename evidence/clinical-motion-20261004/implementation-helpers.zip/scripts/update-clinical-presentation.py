from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=root/'src/clinical/ClinicalIsland.tsx'
s=p.read_text(encoding='utf8')
s=s.replace('svg,width,height,error,nativeFallback','svg,width,height,view,error,nativeFallback')
# Keep the requested-state key live; present the outgoing view for its exit only.
start=s.index(' const trigger=')
s=s[:start]+s[start:].replace('c.view','view')
s=s.replace('width={width+16} height={height} style={{left:-T.geometry.earRadius}}','width={width} height={height} style={{left:0}}')
s=s.replace('<div className="ci-scroll" >','<div className="ci-scroll"><div className="ci-scroll-content">')
s=s.replace('      </div>\n      <footer className="ci-footer">','      </div></div>\n      <footer className="ci-footer">')
s=s.replace('const collapse=()=>{setMenu(false);c.collapse();};','const collapse=()=>{setMenu(false);c.setHovered(false);c.collapse();};')
s=s.replace("'同频 · 安静待命'","'同频 · 在线'")
s=s.replace('<Icon size={T.icon.compactGlyph} strokeWidth={T.icon.stroke}/>','{view===\'idle\'&&!primary&&c.timer.status===\'idle\'?<Pulse size={T.icon.compactGlyph} strokeWidth={T.icon.stroke}/>:<Icon size={T.icon.compactGlyph} strokeWidth={T.icon.stroke}/>}')
p.write_text(s,encoding='utf8')
p=root/'src/clinical/clinical.css'
s=p.read_text(encoding='utf8').replace('pointer-events:none;width:180px;height:34px','pointer-events:none;width:160px;height:34px')
s+='\n/* Accepted U contour is the sole content/native clipping boundary. */\n.ci-clip{border-radius:0}.ci-content[inert]{pointer-events:none}\n.ci-idle .ci-compact-button{padding-left:20px;padding-right:20px;gap:6px}\n.ci-idle .ci-mini{width:18px;height:20px}.ci-scroll-content{display:flow-root;min-width:0}\n'
p.write_text(s,encoding='utf8')
print('Clinical rendering restored to the shared U geometry and staged presentation')
