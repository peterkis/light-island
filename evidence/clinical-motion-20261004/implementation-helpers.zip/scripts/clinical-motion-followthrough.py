from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=root/'tests/clinical-motion.spec.ts';s=p.read_text(encoding='utf8').replace("import T from '../src/clinical/tokens.json';","import T from '../src/clinical/tokens.json' with {type:'json'};");p.write_text(s,encoding='utf8')
p=root/'src/clinical/ClinicalStudio.tsx';s=p.read_text(encoding='utf8').replace('浏览器：无回弹形变。原生：稳定画布、瞬时轮廓和内容渐显，不做逐帧几何 IPC。','恢复 U 型待机。展开与收回沿用旧版轻弹簧节奏，文字不缩放；原生画布保持不动，有限轮廓交接。');p.write_text(s,encoding='utf8')
for name in ['scripts/qa-clinical-boundaries.mjs','scripts/qa-clinical-browser.mjs']:
 p=root/name;s=p.read_text(encoding='utf8').replace("const out='evidence/clinical-20261004';","const out=process.env.ISLAND_QA_OUTPUT||'evidence/clinical-20261004';");p.write_text(s,encoding='utf8')
p=root/'scripts/qa-clinical-native.mjs';s=p.read_text(encoding='utf8').replace('Windows / native WebView2 / clinical safe geometry fallback','Windows / native WebView2 / continuous U-notch motion')
s=s.replace("assert(regions.length<=4,'Two layout mutations maximum per normal transition');","assert(regions.length>8&&regions.length<180,'Finite continuous outline updates, not instant geometry or unbounded polling');")
p.write_text(s,encoding='utf8')
p=root/'scripts/qa-clinical-windows.py';s=p.read_text(encoding='utf8').replace('import ctypes as C,','import os\nimport ctypes as C,').replace("/'evidence/clinical-20261004'","/os.environ.get('ISLAND_QA_OUTPUT','evidence/clinical-20261004')")
s=s.replace("post({'type':'clinical:reset'});move", "post({'type':'clinical:reset'});post({'type':'clinical:configure','settings':{'reduced':False,'textScale':1,'privacy':False,'role':'clinician','locked':False,'fullscreen':False}});move")
s=s.replace('root.after(500,expanded)','root.after(800,expanded)').replace('root.after(250,lambda:click_case','root.after(650,lambda:click_case').replace('root.after(300,capture)','root.after(750,capture)').replace('600+i*650','1000+i*700').replace('root.after(5600,finish)','root.after(6200,finish)').replace('root.after(13000,root.destroy)','root.after(16000,root.destroy)')
p.write_text(s,encoding='utf8')
print('UI copy and regression expectations aligned with continuous native contour')
