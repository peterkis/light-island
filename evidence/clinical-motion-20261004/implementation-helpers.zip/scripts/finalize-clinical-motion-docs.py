from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=root/'scripts/generate-clinical-tokens.mjs';s=p.read_text(encoding='utf8')
s=s.replace("const source=await readFile", "async function update(path,text){let old;try{old=await readFile(path,'utf8');}catch{}if(old!==text)await writeFile(path,text);}\nconst source=await readFile",1)
s=s.replace("await writeFile('src/clinical/tokens.json'","await update('src/clinical/tokens.json'").replace("await writeFile('src/clinical/tokens.css'","await update('src/clinical/tokens.css'")
p.write_text(s,encoding='utf8')
p=root/'docs/Dynamic-Island-UI-Spec.md';s=p.read_text(encoding='utf8')
s=s.replace('[PROPOSED] V1 默认外壳不回弹。贴顶窗口的回弹容易放大遮挡、边界抖动和命中差异，采用 GSAP `power3.out` 展开、`power3.inOut` 收起。保留参考稿的总节奏作为起点，不宣称 Apple 原样。','[PROPOSED] 1.1 默认恢复此前选定的轻弹簧展开：宽度使用 `motion.expand.spring` 的归一化响应，允许有界小超调；高度与收回保持单调 `power3.out`。这不是物理速度连续模拟，更不是 Apple 内部参数。固定画布与原生轮廓交接另行验收，不能用曲线遮掩闪烁。')
s=s.replace('以下均为 `[PROPOSED][VERIFY]` 性能预算，**没有实测结果**。','以下为 `[PROPOSED][VERIFY]` 性能预算；实测必须引用当前 evidence，不能从预算推断已通过。')
p.write_text(s,encoding='utf8')
# Non-authoritative research stays intact; its implementation continuation references 1.1 explicitly.
print('Removed the old no-bounce contradiction; unchanged token generation no longer reloads Vite')
