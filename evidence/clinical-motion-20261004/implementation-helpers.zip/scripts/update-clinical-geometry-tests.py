from pathlib import Path
root=Path(__file__).resolve().parent.parent
p=root/'src-tauri/src/clinical_window.rs';s=p.read_text(encoding='utf8')
s=s.replace('fn ears_are_outside_body_and_geometry_stays_bounded()','fn accepted_u_contour_stays_inside_total_width()').replace('contour(w,h,r,8.0)','contour(w,h,r,7.0)').replace('p[0]>=-8.001&&p[0]<=w+8.001','p[0]>=-0.001&&p[0]<=w+0.001')
s=s.replace('assert!(((pts[0][0]*scale).round()+8.0*scale).abs()<=0.5);','assert!((pts[0][0]*scale).abs()<0.001);')
s=s.replace('assert_eq!(number("/validation/nativeGeometryMutationsPerNormalTransitionMax"),2.0);assert_eq!(number("/geometry/earRadius"),8.0);','assert_eq!(number("/validation/nativeGeometryMutationsPerNormalTransitionMax"),0.0);assert_eq!(number("/geometry/earRadius"),7.0);')
p.write_text(s,encoding='utf8')
# Only update expectations affected by the current UI token contract.
p=root/'tests/clinical-model.test.ts';s=p.read_text(encoding='utf8').replace('ear:8','ear:tokens.geometry.earRadius').replace('w+16','w').replace('(-8.001)','(-.001)').replace('(w+8.001)','(w+.001)');p.write_text(s,encoding='utf8')
print('Geometry test contract updated to inward-ear U contour')
